<?php

namespace App\Http\Controllers\FrontEnd;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class FrontController extends Controller
{
    public function index(){
        return "welcome to landing page";

    }
    public function fronttest(){
        return view('FrontEnd.test');
    }
}
