<?php

namespace App\Http\Controllers\BackEnd;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use DB;
use Session;

class studentManagement extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        return view('BackEnd/studentManagement.student',compact("students"));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //$students=DB::table('student')->get();
        return view('BackEnd/studentManagement.addStudent');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'studentName' => 'required',
            'studentRegNo' => 'required',
            'studnetClassSection' => 'required',
            'studentEmail' => 'required|email|max:255',
            'studentLogInId' => 'required',
            'studentPass' => 'required',
            'studentRollNo'=>'required',
            'studentMob1' => 'required',
            'studentAdd' => 'required',
        ],[
            'studentName.required'=>'Student name is required.',
            'studentRegNo.required' => 'Student registration no is required.',
            'studnetClassSection.required' => 'Student class section is required.',
            'studentEmail.required' => 'Student email is required',
            'studentLogInId' => 'Student login id is required',
            'studentPass' => 'Student Password is required',
            'studentRollNo'=>'Student roll no is required',
            'studentMob1' => 'Student Parent Mobile No 1 is required',
            'studentAdd' => 'Student address is required',
        ]);

        $data=[
           'school_id'=>Auth::guard('admin')->id(),
           'name'=>$request->studentName,
           'registration_no'=>$request->studentRegNo,
        ];
        DB::table('student')->insert($data);
        Session::flash('success_message','Class added successfully');
        return redirect('admin/student');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
