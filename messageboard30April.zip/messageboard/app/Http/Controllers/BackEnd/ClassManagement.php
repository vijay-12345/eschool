<?php

namespace App\Http\Controllers\BackEnd;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use DB;
use Session;
class ClassManagement extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $classes=DB::table('class_section')->get();
        return view('BackEnd/classManagement.class',compact("classes"));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'class' => 'required',
            'section' => 'required',
        ]);
        $data=[
           'school_id'=>Auth::guard('admin')->id(),
           'class_name'=>$request->class,
           'section_name'=>$request->section,
        ];
        DB::table('class_section')->insert($data);
        Session::flash('success_message','Class added successfully');
        return redirect('admin/class');
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $class=DB::table('class_section')->where('id','=',$id)->first();
         return view('BackEnd/classManagement.editClass',compact("class"));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data=[
            'school_id'=>Auth::guard('admin')->id(),
            'class_name'=>$request->class,
            'section_name'=>$request->section,
         ];
         DB::table('class_section')->where('id','=',$id)->update($data);
         Session::flash('success_message','Class updated successfully');
         return redirect('admin/class');
       
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
       DB::table('class_section')->where('id','=',$id)->delete();
       Session::flash('success_message','Class deleted successfully');
       return redirect('admin/class');
    }
}
