<?php

namespace App\Http\Controllers\BackEnd;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use DB;
use Session;

class subjectManagement extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $subjects=DB::table('Subject_master_table')->get();
        return view('BackEnd/subjectManagement.subject',compact("subjects"));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'subject' => 'required',
        ]);
        $data=[
           'subject_name'=>$request->subject,
        ];
        DB::table('Subject_master_table')->insert($data);
        Session::flash('success_message','Subject added successfully');
        return redirect('admin/subject');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
       
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $subject=DB::table('Subject_master_table')->where('id','=',$id)->first();
        return view('BackEnd/subjectManagement.editSubject',compact("subject"));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data=[
            'subject_name'=>$request->subject,
         ];
         DB::table('Subject_master_table')->where('id','=',$id)->update($data);
         Session::flash('success_message','Subject updated successfully');
         return redirect('admin/subject');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
       DB::table('Subject_master_table')->where('id','=',$id)->delete();
       Session::flash('success_message','Subject deleted successfully');
       return redirect('admin/subject');
    }
}
