<?php

namespace App\Http\Controllers\BackEnd;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Session;
use Auth;
use Hash;
class BackController extends Controller
{
    public function index(Request $request){
        if(session("is_active")==1){
            return redirect('admin/dashboard');
        }
        if($request->isMethod('post')){
            $data=$request->all();
            $validatedData = $request->validate([
                'email' => 'required|email|max:255',
                'password' => 'required',
            ]);
            if(Auth::guard('admin')->attempt(['email'=>$data['email'],'password'=>$data['password']])){
                $loggedUserDetails=Auth()->guard("admin")->user();
                session(["is_active"=>1]);
                session(["user_details"=>$loggedUserDetails]);
                return redirect('admin/dashboard');
            }else{
                Session::flash('error_message','Invalid Email or Password');
                return redirect()->back();
            }
        }
        return view('BackEnd.login');
    }
    public function dashboard(){
        return view('BackEnd.dashboard');
    }
    public function logout(){
        Session::flush();
        Auth::guard('admin')->logout();
        return redirect('/admin');
    }
}
