<?php $__env->startSection('title'); ?>
 Class Management | School App
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="panel-header panel-header-sm">
      </div>
      <div class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title"> Class Management</h4>
              </div>
              <div class="card-body>
                <div class="table-responsive">
                <div class="modal-body">
            <form action="<?php echo e(url('admin/class',$class->id)); ?>" method="POST" >
            <input type="hidden" name="_method" value="PUT">
              <div class="form-group">
                <label for="class">Class:</label>
                <input type="text" name="class" class="form-control" placeholder="Enter class name" value="<?php echo e($class->class_name); ?>" id="class">
              </div>
              <div class="form-group">
                <label for="section">Section:</label>
                <input type="text" name="section" class="form-control" placeholder="Enter section name" id="section" value="<?php echo e($class->section_name); ?>">
              </div>
              <?php echo e(csrf_field()); ?>

              <button type="submit" class="btn btn-primary">Update</button>
            </form>
            </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

     
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready( function () {
    $('#dataTable').DataTable();
} );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('BackEnd/layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/messageboard/resources/views/BackEnd/classManagement/editClass.blade.php ENDPATH**/ ?>