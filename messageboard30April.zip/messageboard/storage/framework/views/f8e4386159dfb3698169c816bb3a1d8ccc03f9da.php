<?php $__env->startSection('title'); ?>
 Student Management | School App
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="panel-header panel-header-sm">
      </div>
      <div class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h5 class="title">Add Student Form</h5>
              </div>
              <div class="card-body">
              <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                <?php endif; ?>
                <form action="<?php echo e(url('admin/student')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Name</label>
                        <input type="text" class="form-control" placeholder="Enter Student Name" name="studentName" value="">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Registration No.</label>
                        <input type="text" class="form-control" placeholder="Enter Student Registration Number" name="studentRegNo" value="">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Class-Sec Name</label>
                        <select class="form-control" name="studnetClassSection">
                           <option>select class</option>
                           <option>abc</option>
                           <option>abc</option>
                           <option>abc</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-md-6 ">
                      <div class="form-group">
                      <label>Email</label>
                        <input type="email" class="form-control" name="studentEmail" placeholder="Enter Student Email" >
                      
                        </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                      <label>Phone No</label>
                        <input type="text" class="form-control" name="studentphoneNo" placeholder="Enter Student Phone No">
                       </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                      <label>Roll No</label>
                        <input type="text" class="form-control" name="studentRollNo" placeholder="Enter Student Roll No">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                      <label>Login Id</label>
                        <input type="text" class="form-control" name="studentLogInId" placeholder="Enter Student Login id">
                      
                       </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                      <label>Password</label>
                        <input type="text" class="form-control" name="studentPass" placeholder="Set Password">
                      
                      </div>
                    </div>
                  </div>
                  <div class="row">
                   
                    <div class="col-md-6">
                      <div class="form-group">
                      <label>Parent's Name</label>
                        <input type="text" class="form-control" name="studentParentName" placeholder="Enter Student parent Name">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                      <label>Parent's Mob No 1.</label>
                        <input type="number" class="form-control" name="studentMob1" placeholder="Enter Student Parents Mob no 1.">
                      
                      
                      </div>
                    </div>
                  </div>
                  <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Parent's Mob No 2.</label>
                                <input type="number" class="form-control" name="studentMob2" placeholder="Enter Student Parents Mob no 2.">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Address</label>
                                <textarea rows="4" cols="80" class="form-control" name="studentAdd" placeholder="Enter student's address" value="Mike"></textarea>
                            </div>
                        </div>
                   </div>
                  <div class="row justify-content-center">
                     <div class="col-md-3">
                      <button class="btn btn-primary btn-block">Submit</button>
                     </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        
        </div>
      </div>

     
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready( function () {
    $('#dataTable').DataTable();
} );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('BackEnd/layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/messageboard/resources/views/BackEnd/studentManagement/addStudent.blade.php ENDPATH**/ ?>