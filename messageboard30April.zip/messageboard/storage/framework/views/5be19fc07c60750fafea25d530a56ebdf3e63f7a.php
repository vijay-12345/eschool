<?php $__env->startSection('title'); ?>
 Student Management | School App
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="panel-header panel-header-sm">
      </div>
      <div class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title"> Student Management</h4>
              </div>
              <?php if(Session::has('success_message')): ?>
                     <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(Session::get('success_message')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
              <?php endif; ?>
              <div class="card-body text-right">
  <a href="<?php echo e(url('admin/student/create')); ?>" class="btn btn-primary">Add Class</a>
                <div class="table-responsive">
                <table id="dataTable" class="display">
                        <thead>
                            <tr>
                                <th>S.No</th>
                                <th>Class</th>
                                <th>Section</th>
                                <th>Actions</th>
                            
                            </tr>
                        </thead>
                        <tbody>
                          <?php $id=1; ?>
                          <?php if(!empty($students)): ?>
                          <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?= $id; ?></td>
                                <td><?php echo e($student->class_name); ?></td>
                                <td><?php echo e($student->section_name); ?></td>
                                <td>
        <a href="<?php echo e(url('admin/class',[$class->id,'edit'])); ?>" class="btn btn-primary a-btn-slide-text">
        <i class="fa fa-edit"></i> Edit</span>            
        </a>
                                
    
<a href="javascript:;" class="btn btn-primary a-btn-slide-text" data-toggle="modal" onclick="deleteData(<?php echo e($class->id); ?>)" 
data-target="#DeleteModal" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i> Delete</a>
                                  </td>
    
                            </tr>
                            <?php $id++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="DeleteModal" class="modal fade text-danger" role="dialog">
        <div class="modal-dialog ">
          <!-- Modal content-->
          <form action="" id="deleteForm" method="post">
              <div class="modal-content">
                  <div class="modal-header bg-danger">
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                      <h4 class="modal-title text-center">DELETE CONFIRMATION</h4>
                  </div>
                  <div class="modal-body">
                      <?php echo e(csrf_field()); ?>

                      <?php echo e(method_field('DELETE')); ?>

                      <p class="text-center">Are You Sure Want To Delete ?</p>
                  </div>
                  <div class="modal-footer">
                      <center>
                          <button type="button" class="btn btn-success" data-dismiss="modal">Cancel</button>
                          <button type="submit" name="" class="btn btn-danger" data-dismiss="modal" onclick="formSubmit()">Yes, Delete</button>
                      </center>
                  </div>
              </div>
          </form>
        </div>
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready( function () {
    $('#dataTable').DataTable();
} );
<?php if(count($errors) > 0): ?>
    $('#addClass').modal('show');
<?php endif; ?>
function deleteData(id)
{
    var id = id;
    var url = '<?php echo e(url('admin/class')); ?>';
    url = url+'/'+id;
    $("#deleteForm").attr('action', url);
}

function formSubmit()
{
    $("#deleteForm").submit();
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('BackEnd/layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/messageboard/resources/views/BackEnd/studentManagement/student.blade.php ENDPATH**/ ?>