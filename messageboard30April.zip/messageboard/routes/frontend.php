<?php

Route::get('/','FrontController@index');
Route::get('/fronttest','FrontController@fronttest');