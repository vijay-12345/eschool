<?php

use Cyberduck\LaravelExcel\Factory\ImporterFactory;

abstract class ImporterTest extends TestCase
{
}
